# proyecto taller
 ROOMIES el juego otaku para gente otaku

